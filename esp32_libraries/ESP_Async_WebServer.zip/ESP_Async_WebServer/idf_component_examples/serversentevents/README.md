### Basic example to show how to use ServerSentEvents
